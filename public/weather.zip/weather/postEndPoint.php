<?php
// Allow cross-origin requests (important for ESP32 or frontend access)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "esp32_data";

// Connect to MySQL
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Routing logic
$method = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

// Simple router
if ($method === 'POST' && strpos($uri, '/data') !== false) {
    handlePostData($conn);
} elseif ($method === 'GET' && strpos($uri, '/api/sensor-data') !== false) {
    handleGetLatest($conn);
} elseif ($method === 'GET' && strpos($uri, '/history') !== false) {
    handleGetHistory($conn);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Endpoint not found"]);
}

// ---- END OF MAIN ----

// ===== FUNCTIONS =====

// POST /data — receive ESP32 data
function handlePostData($conn) {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (!$data) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON"]);
        return;
    }

    // $temperature = $data['temperature'] ? 0;
    // $humidity    = $data['humidity'] ? 0;
    // $level       = $data['level'] ?? 0;
    // $rain_status = $data['rain_status'] ?? 0;
    // $rainfall    = $data['rainfall'] ?? 0;
    // $prediction  = $data['prediction'] ?? 0;
    // $pressure    = $data['pressure'] ;
    $temperature = !empty($data['temperature']) ? $data['temperature'] : 0;
$humidity    = !empty($data['humidity']) ? $data['humidity'] : 0;
$level       = !empty($data['level']) ? $data['level'] : 0;
$rain_status = !empty($data['rain_status']) ? $data['rain_status'] : 0;
$rainfall    = !empty($data['rainfall']) ? $data['rainfall'] : 0;
$prediction  = !empty($data['prediction']) ? $data['prediction'] : 0;
    $pressure    = !empty($data['pressure'] ) ? $data['pressure'] : 0;

    $stmt = $conn->prepare("
        INSERT INTO readings 
        (temperature, humidity, level, rain_status, rainfall, prediction, pressure)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        http_response_code(500);
        echo json_encode(["error" => "SQL prepare failed"]);
        return;
    }

    $stmt->bind_param("ddddddd", $temperature, $humidity, $level, $rain_status, $rainfall, $prediction, $pressure);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(["message" => "Data inserted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Database insert failed"]);
    }

    $stmt->close();
}

// GET /api/sensor-data — latest record
function handleGetLatest($conn) {
    // var_dump($conn);
    $sql = "SELECT * FROM readings ORDER BY timestamp DESC LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $row = $result->fetch_assoc()) {
        echo json_encode([
            "rain_status" => (float)$row['rain_status'],
            "rainfall"    => (float)$row['rainfall'],
            "prediction"  => (float)$row['prediction'],
            "temperature" => (float)$row['temperature'],
            "humidity"    => (float)$row['humidity'],
            "pressure"    => (float)$row['pressure'],
            "level"       => (float)$row['level']
        ]);
    } else {
        echo json_encode([
            "rain_status" => 0,
            "rainfall"    => 0,
            "prediction"  => 0,
            "temperature" => 0,
            "humidity"    => 0,
            "pressure"    => 1012,
            "level"       => 0
        ]);
    }
}

// GET /history — last 50 records
function handleGetHistory($conn) {
    $sql = "SELECT * FROM readings ORDER BY timestamp DESC LIMIT 50";
    $result = $conn->query($sql);

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Reverse order (oldest first)
    $data = array_reverse($data);

    echo json_encode($data);
}
?>
